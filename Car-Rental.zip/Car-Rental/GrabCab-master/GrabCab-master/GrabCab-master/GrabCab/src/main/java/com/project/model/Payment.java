package com.project.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="payment")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Payment {

	@Id
	private int payment_id;
	private String payment_type;
	private int amount;
	
/*	 @OneToOne(fetch = FetchType.LAZY)
	  @JoinColumn(name = "trip_id")
	  private Trip trip;
	 
	 
	
	 @OneToOne(fetch = FetchType.LAZY)
	  @JoinColumn(name = "user_id")
	  private User user;*/
	 
	 
}



