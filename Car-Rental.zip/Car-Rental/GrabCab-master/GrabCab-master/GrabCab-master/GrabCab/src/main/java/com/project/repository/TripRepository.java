package com.project.repository;

import org.springframework.data.repository.CrudRepository;

import com.project.model.Trip;

public interface TripRepository  extends CrudRepository<Trip,Integer>{

}
