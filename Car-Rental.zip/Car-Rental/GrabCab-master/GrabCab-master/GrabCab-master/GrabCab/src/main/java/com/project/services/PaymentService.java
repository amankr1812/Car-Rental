package com.project.services;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.project.model.*;
import com.project.repository.PaymentRepository;


@Service
@Transactional
public class PaymentService {



	
	//private final UserRepository userRepository;
	private final PaymentRepository paymentRepository;
	
	public PaymentService(PaymentRepository paymentRepository)
	{
		//this.userRepository=userRepository;
		this.paymentRepository=paymentRepository;
	}
	public void saveMyPayment(Payment payment)
	{
		paymentRepository.save(payment);
	}
	
	public List<Payment> showAllpayments(){
	List<Payment> payments = new ArrayList<Payment>();
	for(Payment payment : paymentRepository.findAll()) {
		payments.add(payment);
	}
	
	return payments;
}

	
	
	

}

