package com.project.services;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.project.model.Car;
import com.project.model.User;
import com.project.repository.CarRepository;
import com.project.repository.UserRepository;

@Service
@Transactional
public class CarService {
	
	//private final UserRepository userRepository;
	private final CarRepository carRepository;
	
	public CarService(CarRepository carRepository)
	{
		//this.userRepository=userRepository;
		this.carRepository=carRepository;
	}
	
//	public List<User> showAllUsers(){
//		List<User> users = new ArrayList<User>();
//		for(User user : userRepository.findAll()) {
//			users.add(user);
//		}
//		
//		return users;
//	}
	
	public List<Car> showAllCars(){
		List<Car> cars = new ArrayList<Car>();	
		for(Car car : carRepository.findAll()) {
			cars.add(car);
		}	
		return cars;
	}
	
	
	public void deleteMyCar(int id) {
		carRepository.deleteById(id);
	}

}
