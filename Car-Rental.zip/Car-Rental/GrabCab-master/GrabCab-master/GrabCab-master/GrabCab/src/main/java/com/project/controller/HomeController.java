package com.project.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.project.model.Payment;
import com.project.model.Trip;
import com.project.model.User;
import com.project.services.CarService;
import com.project.services.PaymentService;
import com.project.services.UserService;
import com.project.services.TripService;

@Controller
public class HomeController {
	
	@Autowired
	private UserService userService;
	@Autowired
	private CarService carService;
	@Autowired
	private TripService tripService;
	
	@Autowired
	private PaymentService paymentService;

	@RequestMapping("/welcome")
	public String welcome(HttpServletRequest request)
	{
		request.setAttribute("mode","MODE_HOME");
		return "welcome";
	}
	
	
	@RequestMapping("/login")
	public String login(HttpServletRequest request)
	{
		request.setAttribute("mode","MODE_LOGIN");
		return "welcome";
	}
	
	@RequestMapping("/register")
	public String registration(HttpServletRequest request)
	{
		request.setAttribute("mode","MODE_REGISTER");
		return "welcome";
	}
	
	@RequestMapping("/planTrip")
	public String planTrip(HttpServletRequest request)
	{
		request.setAttribute("mode","PLAN_TRIP");
		return "welcome";
	}
	
	@PostMapping("/loginCheck")
	public String loginCheck(@ModelAttribute User user,BindingResult bindingResult,HttpServletRequest request)
	{
		userService.loginCheck(user);
		request.setAttribute("cars", carService.showAllCars());
		request.setAttribute("mode","MODE_ADMIN_HOME");
		return "welcome";
	}
	
	@PostMapping("/paymentMode")
	public String savePayment(@ModelAttribute Trip trip,BindingResult bindingResult,HttpServletRequest request)
	{
		tripService.saveMyTrip(trip);
		request.setAttribute("payments", paymentService.showAllpayments());
		request.setAttribute("mode","MODE_PAYMENT");
		
		return "welcome";
	}
	
	@PostMapping("/save-user")
	public String registerUser(@ModelAttribute User user,BindingResult bindingResult,HttpServletRequest request)
	{
		userService.saveMyUser(user);
		request.setAttribute("cars", carService.showAllCars());
		request.setAttribute("mode","ALL_CARS_USER");
		
		return "welcome";
	}
	

	@GetMapping("/show-cars")
	public String showAllCars(HttpServletRequest request) {
		request.setAttribute("cars", carService.showAllCars());
		request.setAttribute("mode", "ALL_CARS_ADMIN");
		return "welcome";
	}
	
	@GetMapping("/show-users")
	public String showAllUsers(HttpServletRequest request) {
		request.setAttribute("users", userService.showAllUsers());
		request.setAttribute("mode", "ALL_USERS");
		return "welcome";
		
	}
	
	
	@PostMapping("/show-payments")
	public String showAllpayments(HttpServletRequest request) {

		request.setAttribute("mode", "MODE_SUCCESS");
		return "welcome";}
	
	
	@RequestMapping("/delete-user")
	public String deleteUser(@RequestParam int id, HttpServletRequest request) {
		userService.deleteMyUser(id);
		request.setAttribute("users", userService.showAllUsers());
		request.setAttribute("mode", "ALL_USERS");
		return "welcome";
	}
	
	@RequestMapping("/delete-car")
	public String deleteCar(@RequestParam int id, HttpServletRequest request) {
		carService.deleteMyCar(id);
		request.setAttribute("cars", carService.showAllCars());
		request.setAttribute("mode", "ALL_CARS_ADMIN");
		return "welcome";
	}
	
	@GetMapping("/show-trips")
	public String showAllTrips(HttpServletRequest request) {
		request.setAttribute("trips", tripService.showAllTrips());
		request.setAttribute("mode", "ALL_TRIPS");
		return "welcome";

}
}
