package com.project.services;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;
import org.springframework.stereotype.Service;

import com.project.model.User;
import com.project.repository.UserRepository;

@Service
@Transactional
public class UserService {
	
	private final UserRepository userRepository;
	
	public UserService(UserRepository userRepository)
	{
		this.userRepository=userRepository;
	}
	
	
	
	public void saveMyUser(User user)
	{
		userRepository.save(user);
	}
	
	public void loginCheck(User user) {
		
		System.out.println("PRINT 1 "+user.getUsername()+"    "+user.getPassword());
		
		String status="not passed";
		String username=user.getUsername();
		String password=user.getPassword();
		
		//ADD AUTHENTICATION HERE
//		
//		userRepository.findAll().forEach(Eachuser->{	
//			
//			if(Eachuser.getUsername().equalsIgnoreCase(username) && Eachuser.getPassword().equalsIgnoreCase(password))
//				status="passed";
//			
//			});
//		
//		return status;
	}

	public List<User> showAllUsers(){
		List<User> users = new ArrayList<User>();
		for(User user : userRepository.findAll()) {
			users.add(user);
		}
		
		return users;
	}
	
	public void deleteMyUser(int id) {
		userRepository.deleteById(id);
	}
}
