package com.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GrabCabApplication {

	public static void main(String[] args) {
		SpringApplication.run(GrabCabApplication.class, args);
	}
}
